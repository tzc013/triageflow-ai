from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.app.core.database import get_db
from backend.app.models.email import Email
from backend.app.models.human_review import HumanReview
from backend.app.models.processing_log import ProcessingLog
import datetime

router = APIRouter(prefix="/api/review", tags=["Human Review"])

@router.get("")
def get_review_items(db: Session = Depends(get_db)):
    # Retrieve all emails requiring human review or in needs_review status
    emails = db.query(Email).filter(
        (Email.requires_human == True) | (Email.status == "needs_review")
    ).order_by(Email.timestamp.desc()).all()

    items = []
    for e in emails:
        # Determine specific review queue bucket
        bucket = "needs_review"
        if e.confidence < 0.65:
            bucket = "low_confidence"
        elif e.priority in ("high", "critical"):
            bucket = "high_importance"
        elif e.status == "needs_review":
            bucket = "awaiting_approval"

        items.append({
            "id": e.id,
            "sender_name": e.sender_name,
            "sender_email": e.sender_email,
            "subject": e.subject,
            "clean_body": e.clean_body[:160] + ("..." if len(e.clean_body) > 160 else ""),
            "timestamp": e.timestamp.isoformat() if e.timestamp else None,
            "category": e.category,
            "priority": e.priority,
            "confidence": e.confidence,
            "reason": e.reason,
            "recommended_action": e.recommended_action,
            "status": e.status,
            "rag_used": e.rag_used,
            "bucket": bucket,
        })

    return {
        "items": items,
        "counts": {
            "all": len(items),
            "needs_review": len([i for i in items if i["bucket"] == "needs_review"]),
            "low_confidence": len([i for i in items if i["bucket"] == "low_confidence"]),
            "high_importance": len([i for i in items if i["bucket"] == "high_importance"]),
            "awaiting_approval": len([i for i in items if i["bucket"] == "awaiting_approval"]),
        }
    }

@router.post("/{email_id}/resolve")
def resolve_review(email_id: str, action: str = "approve", db: Session = Depends(get_db)):
    email = db.query(Email).filter(Email.id == email_id).first()
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    
    email.status = "resolved"
    email.requires_human = False

    db.add(ProcessingLog(
        id=f"log_resolved_{email_id}_{datetime.datetime.utcnow().timestamp()}",
        email_id=email_id,
        event_type="human_escalated",
        status="success",
        details=f"Human Reviewer resolved item with action: '{action}'"
    ))
    db.commit()
    return {"status": "success", "message": f"Item {email_id} marked as resolved with {action}"}
