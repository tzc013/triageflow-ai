import datetime
from sqlalchemy import Column, String, Integer, Float, Boolean, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from backend.app.core.database import Base

class Email(Base):
    __tablename__ = "emails"

    id = Column(String, primary_key=True, index=True)
    provider = Column(String, default="demo")
    provider_message_id = Column(String, unique=True, index=True)
    thread_id = Column(String, index=True, nullable=True)
    sender_name = Column(String, default="")
    sender_email = Column(String, index=True)
    recipient = Column(String, default="contact@northstarestates.com")
    cc = Column(String, default="", nullable=True)
    subject = Column(String, index=True)
    clean_body = Column(Text, default="")
    raw_body = Column(Text, default="")
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Classification & Decision
    category = Column(String, default="other", index=True)
    priority = Column(String, default="normal", index=True) # low, normal, high, critical
    confidence = Column(Float, default=0.0)
    requires_human = Column(Boolean, default=False)
    recommended_action = Column(String, default="human_review")
    reason = Column(Text, default="")
    
    # Execution status
    status = Column(String, default="processed", index=True) # unread, processing, processed, needs_review, resolved, archived, spam
    rag_used = Column(Boolean, default=False)
    rag_sources = Column(Text, default="[]") # JSON string of sources
    response_sent = Column(Boolean, default=False)
    generated_reply = Column(Text, default="", nullable=True)
    forwarded_to = Column(String, default="", nullable=True)
    discord_status = Column(String, default="none") # none, sent, failed, simulated
    
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

    # Relationships
    attachments = relationship("EmailAttachment", back_populates="email", cascade="all, delete-orphan")
    decisions = relationship("EmailDecision", back_populates="email", cascade="all, delete-orphan")
    logs = relationship("ProcessingLog", back_populates="email", cascade="all, delete-orphan")
    human_reviews = relationship("HumanReview", back_populates="email", cascade="all, delete-orphan")
